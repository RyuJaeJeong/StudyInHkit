package Test09New;

public class PhoneBookUse {

	public static void main(String[] args) {
		
		
		
		
		PhoneBook pbu1 = new PhoneBook();
		
		PhoneBook pbu2 = new PhoneBook();
		
		PhoneBook pbu3 = new PhoneBook();
	

		pbu1.display();
		pbu2.display();
		pbu3.display();
		
		
	}

}
