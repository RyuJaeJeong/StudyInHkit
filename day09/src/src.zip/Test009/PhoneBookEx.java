package Test009;

import java.util.Scanner;

public class PhoneBookEx {
	public static void main(String[] args) {
		
		
		
		PhoneBook pb1 = new PhoneBook();
		PhoneBook pb2 = new PhoneBook();
		PhoneBook pb3 = new PhoneBook();
		
		pb1.display();
		pb2.display();
		pb3.display();


	
	}
	

}
