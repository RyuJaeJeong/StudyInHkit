package time_morning;

public class Child extends Parent {
	//Member Field
	int number2 = 30;
	//constructor
	//Member Method
}
