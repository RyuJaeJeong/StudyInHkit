package time_morning;

public class Parent {
	//Member Field
	String name = "������";
	int number1 = 21;
	//Constructor
	//Member method
	
}
