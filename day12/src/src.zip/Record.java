
public class Record {

	
		//Field
		private String name;
		private int lang;
		private int mat;
		private int eng;
		//cons
		public Record() {
			// TODO Auto-generated constructor stub
		}
		//method
		
		//Getter&Setter
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getLang() {
			return lang;
		}
		public void setLang(int lang) {
			this.lang = lang;
		}
		public int getMat() {
			return mat;
		}
		public void setMat(int mat) {
			this.mat = mat;
		}
		public int getEng() {
			return eng;
		}
		public void setEng(int eng) {
			this.eng = eng;
		}
		
		
		
		

	}


