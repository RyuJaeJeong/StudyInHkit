package time_morning3;

public class dog extends Animal {

	public dog(String name, int age) {
		super(name, age);
	}
	
	public void sound () {
		System.out.println("--�۸�--");
	}
	
	 
	
	
}
