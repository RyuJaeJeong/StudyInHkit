package time_morning3;

	public class bird extends Animal {
		public bird(String name, int age) {
			super(name,age);
		}
		public void sound() {
			System.out.println("--±±--");
		}
	}	
