package time_morning3;

public class cat extends Animal {
	
	public cat(String name, int age) {
		super(name,age);
	}

	
	public void sound() {
		System.out.println("--�߿�--");
	}
}
